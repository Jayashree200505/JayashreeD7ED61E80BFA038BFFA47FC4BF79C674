"""
write a function called linear_search_product that takes the list of products and a target product
name as input. The function shoyld perform a linear search to find the target product in the list and 
returns a list of indices of all occurences of the product of found, or an empty list of the product is not
found.
"""


def linearSearchProduct(productList, targetProduct):
  indices = []

  for index,product in enumerate(productList):
    if product == targetProduct:
       indices.append(index)

  return indices


# Example usage:
product = ["shoes","boot","loafer","shoes","sandal","shoes"]
target = "shoes"
target2 = "apple"
result = linearSearchProduct(product,target)
print(result)